from final_story_script import beginning, middle, ending

def test_beginning():
    assert isinstance(beginning(), str)
    
    
    
def test_middle():
    assert isinstance(middle(), str)
    

    
def test_ending():
    assert isinstance(ending(), str)